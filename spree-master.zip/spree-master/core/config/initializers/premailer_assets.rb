Rails.application.config.assets.precompile += %w( ink.css )
