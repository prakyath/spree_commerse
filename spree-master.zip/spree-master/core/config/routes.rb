Spree::Core::Engine.draw_routes
