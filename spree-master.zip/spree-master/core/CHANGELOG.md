## Spree 3.0.0 (unreleased) ##

* Renamed ItemAdjustments to Adjustable::AdjustmentsUpdater.
* Removed allow_ssl_in_* preferences from spree
