Rails.application.config.assets.precompile += %w( jquery-ui/* )
