module Spree
  module Admin
    class ReturnAuthorizationReasonsController < ResourceController
    end
  end
end
