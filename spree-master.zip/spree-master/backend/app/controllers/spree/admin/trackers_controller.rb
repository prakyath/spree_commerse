module Spree
  module Admin
    class TrackersController < ResourceController
    end
  end
end
