## Spree 3.0.0 (unreleased) ##

* Deprecate the Spree::Api::ConfigController
