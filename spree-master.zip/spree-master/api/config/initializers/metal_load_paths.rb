Spree::Api::BaseController.append_view_path(ApplicationController.view_paths)
